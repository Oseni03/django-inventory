from setuptools import setup

setup(
    package_data={"inventory": ["templates/inventory", "static/inventory"]}
  )